<?php

$email = $_POST['email'];
$nimi = $_POST['nimi'];
$aika = $_POST['aika'];
$paikka = $_POST['paikka'];
$pv = $_POST['pv'];
$millon = $_POST['millon'];
$txt = "$email,$nimi,$aika,$paikka,$pv,$millon";
$myfile = file_put_contents('moi.csv', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>thgfhfgh</title>
</head>
<body>
    Tallennettu:<br>
    <?= $email ?>
    <?= $nimi ?>
    <?= $aika ?>
    <?= $paikka ?>
    <?= $pv ?>
    <?= $millon ?>
    <a href="moi.html">Varaukset</a>
</body>
</html>