function poisto() {
    let poistaminen = document.getElementById("container"); // hakee containerin ja tallentaa sen muuttujaan 'poistaminen
    container.remove(); // poistaa containerin
}