function poisto() {
    let gfg_down =
        document.getElementById("container");
    container.remove();
}