console.log("JEEEE OMG!") // testi

const canvas = document.getElementById('canvaasi'); // määritellään muuttuja
const ctx = canvas.getContext('2d'); // wow se on 2d (en ois arvannu)

let raf; // määrittelee muuttujan, mutta sen arvoa voi vaihtaa
let inputStates = {} // näppäintenpainallukset tänne talteen
window.addEventListener('keydown', function(event){
  console.log(event.key);
  if (event.key == "ArrowRight") {
    console.log("Oikea nuoli painettu.")
    inputStates.right = true;
  }
  if (event.key == "ArrowLeft") {
    console.log("Vasen puoli painettu.")
    inputStates.left = true;
  }
}, false);

window.addEventListener('keyup', function(event) {
if (event.key == "ArrowRight"); {
inputStates.right = false;
}

if (event.key == "ArrowLeft"); {
  inputStates.left = false;
}
}, false); 
const ball = {  // pallo
  x: 50,
  y: 50,
  vx: 6, // nopeus ja suunta
  vy: 3,
  radius: 15,
  color: 'white',
  draw() { // funktio
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.fillStyle = this.color;
    ctx.fill();
  }
};

const maila = { // maila
  x: 300,
  y: 390,
  vx:10,
  leveys: 75,
  korkeus: 10,
  color: 'black',
  draw() { // funktio
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x, this.y, this.leveys, this.korkeus)
  }
};

function draw() { // wow se liikkuu (real)
  ctx.clearRect(0,0, canvas.width, canvas.height); // tyhjennetään kaikki
  ball.draw(); // piirtää maailman
  maila.draw();
  ball.x += ball.vx; // liikuttaa pelimaailmaa
  ball.y += ball.vy;

  if (inputStates.right) {
    maila.x = maila.x + maila.vx


  }

  if (inputStates.left) {
    maila.x = maila.x - maila.vx


  }

  if (ball.y + ball.radius > canvas.height || // boing boing
      ball.y - ball.radius < 0) {
    ball.vy = -ball.vy;
  }
  if (ball.x + ball.radius > canvas.width ||
      ball.x - ball.radius < 0) {
    ball.vx = -ball.vx;
  }

if (maila.x < 0) {
  maila.x = 0;
}

if (maila.x + maila.leveys > canvas.width) {
  maila.x = canvas.width - maila.leveys;
}

var testX = ball.x;
var testY = ball.y;

if (testX < maila.x) testX = maila.x;
else if (testX > (maila.x + maila.leveys)) (testX = maila.x + maila.leveys);
if (testY < maila.x) testY = maila.y
else if (testY > (maila.x + maila.korkeus)) (testX = maila.x + maila.korkeus);

var distX = ball.x - testX;
var distY = ball.y - testY;
var dista = Math.sqrt((distX*distX) + (distY * distY));

if (dista <= ball.radius) {
  if (ball.x >= maila.x && ball.x <= (maila.x + maila.leveys)) {
    ball.vx *= -1;
  }
}

  raf = window.requestAnimationFrame(draw);
}

draw(); // suorittaa funktion