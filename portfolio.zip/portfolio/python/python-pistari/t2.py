ika = int(input("Minkä ikäinen olet? "))

if ika < 18:
    print("Et ole täysi-ikäinen!")

if ika >= 18:
    print("Olet täysi-ikäinen!")