valinta = int(input(" Mitä valitset:\n 1 - menen kahville\n 2 - menen kotiin\n 3 - menen kouluun\n 4 - menen koodaamaan\n 5 - menen pois\n "))

if valinta == 1:
    print(" Ota kahvin kanssa myös kakkua :-)")
    
if valinta == 2:
    print(" Hyvää kotimatkaa!")
    
if valinta == 3:
    print(" Opiskele ahkerasti!")
    
if valinta == 4:
    print(" Tervetuloa!")
    
if valinta == 5:
    print(" Kiitos käynnistä!")