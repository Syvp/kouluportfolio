luku1 = int(input("Anna jokin luku: "))
luku2 = int(input("Anna jokin toinen luku: "))

if luku1 < luku2:
    print(luku2)
    
if luku2 < luku1:
    print(luku1)
    
if luku1 == luku2:
    print("Yhtä suuria")    