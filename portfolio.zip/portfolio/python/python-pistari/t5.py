ika = int(input("Kerro ikäsi: "))

if ika < 18 or ika > 80:
    print("Et pääse.")

else:
    print("Pääset!")        