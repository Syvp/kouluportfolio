pisteet = int(input("Paljonko pisteitä sait? "))

if pisteet > 0 and pisteet < 50:
    print("0")
    
if pisteet > 51 and pisteet < 70:
    print("1")
    
if pisteet > 71 and pisteet < 90:
    print("2")
    
if pisteet > 91 and pisteet < 100:
    print("3")