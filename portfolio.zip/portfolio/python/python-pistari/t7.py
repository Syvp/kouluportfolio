numero = 1

while numero <= 27:
    print(numero)
    numero += 1